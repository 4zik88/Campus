<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:2:{s:4:"cron";a:3:{i:0;O:24:"wfWAFCronFetchRulesEvent":1:{s:11:" * fireTime";i:1647168797;}i:1;O:25:"wfWAFCronFetchIPListEvent":1:{s:11:" * fireTime";i:1646997436;}i:2;O:36:"wfWAFCronFetchBlacklistPrefixesEvent":1:{s:11:" * fireTime";i:1646917697;}}s:20:"whitelistedURLParams";a:1:{s:57:"L3dwLWFkbWluL2VkaXQucGhw|cmVxdWVzdC5xdWVyeVN0cmluZ1t0YWJd";a:1:{i:9;a:5:{s:9:"timestamp";i:1645785569;s:11:"description";s:35:"Allowlisted while in Learning Mode.";s:6:"source";s:13:"learning-mode";s:2:"ip";s:13:"195.110.58.43";s:6:"userID";i:0;}}}}